# Açıklama

Telefon çaldı, ekranda "Annem" yazıyor. Ses de onun sesi. Açar mısın? 📞

Yapay zeka artık birinin sesini sosyal medyadaki birkaç saniyelik bir videodan kopyalayabiliyor. İçeride örnek bir dolandırıcı konuşması var: kaç tuzak olduğunu say, sonra cevaba bak.

💬 Yorumlara yaz: AÇARIM mı AÇMAM mı, kaç tuzak buldun?
👥 Bunu bilmesi gereken birini etiketle, özellikle anne babanı.
➤ Ailenin WhatsApp grubuna gönder, aile şifrenizi bu akşam belirleyin.

Takipte kal: @farukcreative

#yapayzeka #dolandırıcılık #siberguvenlik #deepfake #farkındalık

# İlk yorum

Kaynaklar: McAfee "The Artificial Imposter" araştırması (7 ülkede 7.054 kişi; 3 saniyelik ses %85 benzerlikte kopya için yetti, yetişkinlerin %70'i klon sesi ayırt edebileceğinden emin değil, mağdurların %77'si para kaybetti). Anadolu Ajansı, 18 Aralık 2025: Türkiye'de uzmanlar yapay zekayla ses klonlama dolandırıcılığına karşı uyardı.
