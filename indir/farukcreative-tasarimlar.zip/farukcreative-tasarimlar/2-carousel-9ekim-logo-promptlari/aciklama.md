# Açıklama

Yapay zekaya "logo yap" yazıp vasat sonuç alıyorsan sorun araçta değil, promptta. 👀

İyi bir logo promptu 5 parçadan oluşur: stil + sembol + renk + arka plan + kısıt. İçeride dünyanın en ünlü 6 logosundaki stiller (Warner Bros, FedEx, Duolingo, Starbucks, Dior, Mastercard) ve her biri için kopyala-yapıştır prompt var.

📌 Kaydet, logo lazım olduğunda elinin altında olsun.
💬 Hangi formülü ilk deneyeceksin? Yorumlara numarasını ve markanı yaz. En çok istenen markayı bir sonraki "Aynı prompt, 5 yapay zeka" bölümünde tasarlıyorum.

Takipte kal: @farukcreative

#yapayzeka #logotasarımı #grafiktasarım #prompt #branding

# İlk yorum

Formüllerin tamamı (kopyala, kendi markana göre değiştir):

01 Monogram logo design, the letters "WB" interlocked inside a classic shield crest, bold condensed sans-serif letters, Hollywood film studio emblem, royal blue on a white background, symmetrical, flat vector, clean sharp edges, no gradients, no extra text

02 Negative space wordmark logo, the word "FedEx" with a hidden right-pointing arrow in the white space between the E and the x, heavy bold sans-serif, tight letter spacing, "Fed" in purple, "Ex" in orange, white background, flat vector, minimal, no shadows, no gradients

03 Mascot logo, a friendly round cartoon owl with huge expressive eyes and a small orange beak, chubby body built from simple rounded shapes, bright green feathers, thick clean outlines, front-facing app icon style, white background, flat vector, playful, no gradients, no text

04 Circular emblem logo for a coffee brand, a crowned two-tailed siren with long wavy hair in the center, enclosed in a double ring, symmetrical, clean line art, deep green and white only, flat vector, no gradients, no text

05 Luxury fashion wordmark logo, the word "DIOR" in an elegant high-contrast Didone serif, all caps, thin hairlines and thick stems, wide letter spacing, black letters on a soft cream background, centered, minimal, flat vector, no icon, no ornaments

06 Geometric logo mark, two equal overlapping circles side by side, red on the left, yellow on the right, the overlap in orange, perfectly balanced, solid black background, flat vector, minimal, no text, no gradients, no outlines
