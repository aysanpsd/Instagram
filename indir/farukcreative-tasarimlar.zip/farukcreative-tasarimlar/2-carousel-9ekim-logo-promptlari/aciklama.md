# Açıklama

Yapay zekaya "logo yap" yazıp vasat sonuç alıyorsan sorun araçta değil, promptta. 👀

İyi bir logo promptu 5 parçadan oluşur: stil + sembol + renk + arka plan + kısıt. İçeride dünyanın en ünlü 6 logosundaki stiller (Warner Bros, FedEx, Duolingo, Starbucks, Dior, Mastercard) ve her biri için kopyala-yapıştır prompt var.

📌 Kaydet, logo lazım olduğunda elinin altında olsun.
💬 Hangi formülü ilk deneyeceksin? Yorumlara numarasını ve markanı yaz. En çok istenen markayı bir sonraki "Aynı prompt, 5 yapay zeka" bölümünde tasarlıyorum.

Takipte kal: @farukcreative

#yapayzeka #logotasarımı #grafiktasarım #prompt #branding

# İlk yorum

Formüllerin tamamı:
01 minimalist monogram logo, letters "FK", geometric, single line weight, black on white, flat vector
02 negative space logo combining a coffee cup and a book, flat vector, two colors
03 friendly mascot logo of a fox wearing headphones, bold outlines, 3 colors, sticker style
04 circular emblem logo for a coffee brand, central character, two colors, clean lines
05 luxury serif wordmark logo "AURA", high contrast, wide letter spacing, gold on black
06 geometric logo mark, two interlocking circles, overlap in a third color, flat, minimal
