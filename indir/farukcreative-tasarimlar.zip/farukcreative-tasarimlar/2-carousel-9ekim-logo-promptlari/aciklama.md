# Açıklama

Yapay zekaya "logo yap" yazıp vasat sonuç alıyorsan sorun araçta değil, promptta. 👀

İyi bir logo promptu 5 parçadan oluşur: stil + sembol + renk + arka plan + kısıt. İçeride dünyanın en ünlü 6 logosundaki stiller (Warner Bros, FedEx, Duolingo, Starbucks, Dior, Mastercard) ve her biri için kopyala-yapıştır prompt var.

📌 Kaydet, logo lazım olduğunda elinin altında olsun.
💬 Hangi formülü ilk deneyeceksin? Yorumlara numarasını ve markanı yaz. En çok istenen markayı bir sonraki "Aynı prompt, 5 yapay zeka" bölümünde tasarlıyorum.

Takipte kal: @farukcreative

#yapayzeka #logotasarımı #grafiktasarım #prompt #branding

# İlk yorum

Formüllerin tamamı:
01 monogram logo, letters "WB" inside a shield crest, bold blue on white, flat vector
02 negative space wordmark "FedEx", hidden arrow between the E and the x, bold sans-serif, purple and orange, flat vector
03 friendly mascot logo of a round green owl with big eyes, bold outlines, flat colors, sticker style
04 circular emblem logo for a coffee brand, a crowned two-tailed siren in the center, green and white, clean lines
05 luxury serif wordmark logo "DIOR", high contrast, wide letter spacing, black on cream
06 geometric logo mark, two overlapping circles, red and yellow, orange where they overlap, flat, minimal
